
import java.math.RoundingMode;
import java.text.DecimalFormat;

public class InsuredPackage extends Package implements IPackage{
   private final double[] insurance = {2.45, 3.95, 5.55};
   private double shippingBefore;
	private double shippingCost;
	private double insuranceCost;
	
	public InsuredPackage(int weight, char shippingMethod)
	{
		super(weight, shippingMethod);
		
		this.calculateShipping();
	}
	
   @Override
	public void calculateShipping()
	{
		shippingBefore = super.getShippingCost();
		if(shippingBefore >= 1.00 && shippingBefore <= 1.00)
			insuranceCost = insurance[0];
		else if(shippingBefore >= 1.01 && shippingBefore <= 3.00)
			insuranceCost = insurance[1];
		else if(shippingBefore >= 3.01)
			insuranceCost = insurance[2];
		
		shippingCost = shippingBefore + insuranceCost;
	}
	
   @Override
	public void display()
	{
      DecimalFormat f = new DecimalFormat("0.00");
		
		String displayString = "";
		displayString += "Weight: " + super.getWeight();
		displayString += "\nShipping Method: " + super.getShippingMethod();
		displayString += "\nShipping Cost with insurance: $" + f.format(shippingCost);
      
      System.out.println(displayString);
	}
}