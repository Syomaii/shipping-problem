import java.util.Scanner;
public class UsePackage{
   public static void main(String[] args){
      Scanner input = new Scanner(System.in);
      
      System.out.print("Enter weight in pounds: ");
      int weightHolder = input.nextInt();
      
      System.out.print("Choose mode of delivery: ");
      char shipMethodHolder = input.next().charAt(0);
      
      System.out.println("1. Air");
      System.out.println("2. Truck");
      System.out.println("3. Mail");
      
      InsuredPackage Ipackage1 = new InsuredPackage(weightHolder, shipMethodHolder);
      System.out.println("\nDisplaying Packages");
      Ipackage1.display();
      
      
   }
}