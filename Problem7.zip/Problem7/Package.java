
import java.math.RoundingMode;
import java.text.DecimalFormat;

public abstract class Package implements IPackage{
   private double weight;
   private char shippingMethod;
   private double shippingCost;
   
   private double[] costAir = {2.00, 3.00, 4.50};
   private double[] costTruck = {1.50, 2.35, 3.25};
   private double[] costMail = {.50, 1.50, 2.15};   
   
   public Package(int weight, char shippingMethod){
      setWeight(weight);
      setShippingMethod(shippingMethod);
      calculateCost();
   }
   
   public void setWeight(double weight){
      this.weight = weight;
   }
   
   public double getWeight(){
      return weight;
   }
   
   public double getShippingCost(){
      return shippingCost;
   }
   
   public char getShippingMethod(){
      return shippingMethod;
   }
   
   public void setShippingMethod(char shippingMethod){
      switch(shippingMethod){
         case '1':
            this.shippingMethod = 'A'; 
            break;   
         case '2': 
            this.shippingMethod = 'T';
            break;
         case '3':
            this.shippingMethod = 'M';
            break;
         default:
            System.out.println("Invalid value try again: ");
            break;
      }
   }

   public void calculateCost(){
      switch(getShippingMethod()){
         case 'A':
            if(getWeight() >= 1 && getWeight() <= 8)
               shippingCost = costAir[0];
            else if (getWeight() >= 9 && getWeight() <= 16)
               shippingCost = costAir[1];
            else if (getWeight() >= 17)
               shippingCost = costAir[2];
         break;
         case 'T':
            if(getWeight() >= 1 && getWeight() <= 8)
               shippingCost = costTruck[0];
            else if (getWeight() >= 9 && getWeight() <= 16)
               shippingCost = costTruck[1];
            else if (getWeight() >= 17)
               shippingCost = costTruck[2];
         break;
         case 'M':
            if(getWeight() >= 1 && getWeight() <= 8)
               shippingCost = costMail[0];
            else if (getWeight() >= 9 && getWeight() <= 16)
               shippingCost = costMail[1];
            else if (getWeight() >= 17)
               shippingCost = costMail[2];
         break;
      }
   }
   
   public void display(){
      DecimalFormat f = new DecimalFormat("0.00");
      
		String displayString = "";
		displayString += "Weight in ounces: " + getWeight();
		displayString += "\nShipping Method: " + getShippingMethod();
		displayString += "\nShipping Cost: $" + f.format(this.shippingCost);
      
      System.out.println(displayString);
   }
}