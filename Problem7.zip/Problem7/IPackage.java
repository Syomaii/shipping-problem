public interface IPackage{
   
   public void calculateShipping();
   public void display();
   
   public char getShippingMethod();
   public double getWeight();
   
   public void setWeight(double weightInOunces);
   public void setShippingMethod(char shippingMethod);
}